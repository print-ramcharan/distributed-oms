package com.oms.fulfillmentservice.domain;

public enum FulfillmentStatus {
    INITIATED, 
    DISPATCHED, 
    FAILED 
}
