package com.oms.orderservice.domain.idempotency;

public enum IdempotencyStatus {
    IN_PROGRESS,
    COMPLETED
}
