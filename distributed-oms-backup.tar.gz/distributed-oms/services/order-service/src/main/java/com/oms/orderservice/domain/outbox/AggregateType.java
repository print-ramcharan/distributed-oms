package com.oms.orderservice.domain.outbox;

public final class AggregateType {

    private AggregateType() {}

    public static final String ORDER = "ORDER";
}
