package com.oms.orderservice.domain.model;

public enum OrderStatus {
    PENDING,     
    COMPLETED,   
    CANCELLED,   
    FAILED       
}



