package com.oms.orderservice.common.exception;

public class ApiExceptionHandle {
}
