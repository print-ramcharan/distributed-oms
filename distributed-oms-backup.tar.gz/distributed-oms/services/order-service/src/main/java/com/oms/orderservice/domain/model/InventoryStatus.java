package com.oms.orderservice.domain.model;

public enum InventoryStatus {
    PENDING,
    RESERVED,
    RELEASED,
    FAILED
}
