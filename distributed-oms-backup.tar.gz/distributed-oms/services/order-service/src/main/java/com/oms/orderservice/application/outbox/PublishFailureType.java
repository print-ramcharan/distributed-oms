package com.oms.orderservice.application.outbox;

public enum PublishFailureType {
    TRANSIENT,
    PERMANENT
}
