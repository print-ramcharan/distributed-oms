package com.oms.orderservice.domain.outbox;

public enum OutboxStatus {
    NEW,
    SENT,
    FAILED
}
